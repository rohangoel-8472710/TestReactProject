import React, { Component } from 'react';
import axios from 'axios';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TextInput,
  FlatList,
  Button,
} from 'react-native';


export default class App extends React.Component {
  constructor() {
    super()
    this.state = {
      articles:[]
    }
  }
  componentDidMount() {
    axios.get('https://newsapi.org/v2/everything?q=noida&apiKey=6e44b6acc6564f6eb35e3ac41763447f')
      .then(response => {
        console.warn(response.data);
        this.setState({articles:response.data.articles})
      })
      .catch(function (error) {
        console.warn(response)
      });
  }
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.vStyle}>
          <Text style={{ fontSize: 20 }}>Home</Text>
        </View>
        <View style={{ flexDirection: "row", justifyContent: 'flex-start' }}>
          <Text style={{ margin: 20, fontSize: 18, fontStyle: 'normal' }}>Search</Text>
          <TextInput style={styles.tStyle}></TextInput>
          <Button title='Press'
           color="green"
           style={styles.bStyle}/>
        </View>
        <FlatList
          data={this.state.articles}
          renderItem={({ item, index}) => {
            return (
              <View style={styles.nStyle}>
                <Text style={styles.mStyle}>Title:{this.state.articles[index].title}</Text>
                <Text style={styles.mStyle}>Description:{this.state.articles[index].description}</Text>
              </View>
            )
          }}
        />
      </SafeAreaView>
    )
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
  },
  vStyle: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'orange'
  },
  tStyle: {
    margin: 10,
    flex: 1,
    padding: 10,
    backgroundColor: 'gray',
    borderRadius: 62.5,
    paddingEnd: 20
  },
  mStyle:{
    fontWeight:'bold',
    flex:1,
    marginTop:30,
    padding:10,
    justifyContent:'center',
    backgroundColor:'white'

  },
  nStyle:{
    padding:10,
    marginLeft:20,
    borderWidth:20,
    borderColor:'#33FFD7',
    margin:20
  },
  bStyle:{
    padding: 20,
    height:20,
    width:20,
    marginTop:'30%',
    borderRadius:10
    },
   imgStyle:{
     position:'absolute',
     
   }
}); 